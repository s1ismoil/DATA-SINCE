# Welcome to My Nba Game Analysis

Thank you

## Task
What is the problem? And where is the challenge?

I had a little problem with the project, 

but I was able to solve the problem
## Description
How have you solved the problem?


I solved the problem using project videos


## Installation
How to install your project? npm install? make? make re?

The project can be accessed via python my_nba_game_analysis.py

## Usage
How does it work?

the project analyzes the game of basketball

```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
